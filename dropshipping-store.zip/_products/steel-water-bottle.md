---
layout: product
title: Stainless Steel Water Bottle
id: 5
name: Stainless Steel Water Bottle
price: 24.99
description: Eco-friendly double-walled insulated water bottle that keeps drinks cold for 24 hours or hot for 12 hours. Leak-proof and BPA-free.
category: Home
image: /assets/images/product-waterbottle.jpg
supplier_id: SUPP004
supplier_sku: WB-500-SLV
---
