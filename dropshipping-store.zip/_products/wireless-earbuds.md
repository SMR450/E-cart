---
layout: product
title: Premium Wireless Earbuds
id: 1
name: Premium Wireless Earbuds
price: 49.99
description: High-quality wireless earbuds with noise cancellation, touch controls, and 30-hour battery life. Perfect for music lovers and professionals on the go.
category: Electronics
image: /assets/images/product-earbuds.jpg
supplier_id: SUPP001
supplier_sku: WE-2025-BLK
---
