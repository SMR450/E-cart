---
layout: product
title: Smart Fitness Watch
id: 2
name: Smart Fitness Watch
price: 79.99
description: Track your fitness goals with this advanced smartwatch featuring heart rate monitoring, sleep tracking, and smartphone notifications. Water-resistant and long battery life.
category: Electronics
image: /assets/images/product-smartwatch.jpg
supplier_id: SUPP002
supplier_sku: FW-350-SLV
---
