---
layout: product
title: Minimalist Backpack
id: 3
name: Minimalist Backpack
price: 39.99
description: Stylish and functional backpack with laptop compartment, water bottle pockets, and anti-theft features. Perfect for commuters and travelers.
category: Fashion
image: /assets/images/product-backpack.jpg
supplier_id: SUPP003
supplier_sku: BP-101-GRY
---
