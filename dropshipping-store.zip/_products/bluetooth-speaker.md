---
layout: product
title: Portable Bluetooth Speaker
id: 4
name: Portable Bluetooth Speaker
price: 34.99
description: Compact yet powerful Bluetooth speaker with 12-hour playtime, waterproof design, and rich bass. Take your music anywhere with this premium portable speaker.
category: Electronics
image: /assets/images/product-speaker.jpg
supplier_id: SUPP001
supplier_sku: BS-220-BLU
---
