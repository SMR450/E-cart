---
layout: product
title: LED Desk Lamp
id: 6
name: LED Desk Lamp
price: 29.99
description: Modern LED desk lamp with adjustable brightness levels, color temperatures, and flexible arm. Energy-efficient and perfect for home office or study.
category: Home
image: /assets/images/product-desklamp.jpg
supplier_id: SUPP005
supplier_sku: DL-300-WHT
---
