// JavaScript for handling payment integration with PayPal
document.addEventListener('DOMContentLoaded', function() {
  // PayPal button configuration
  function initPayPalButton() {
    if (document.querySelector('.paypal-button-container')) {
      paypal.Buttons({
        style: {
          shape: 'rect',
          color: 'blue',
          layout: 'vertical',
          label: 'paypal',
        },
        
        createOrder: function(data, actions) {
          // Get cart items from localStorage
          const cart = JSON.parse(localStorage.getItem('dropshop-cart')) || [];
          const orderTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
          
          return actions.order.create({
            purchase_units: [{
              description: 'DropShop Order',
              amount: {
                currency_code: 'USD',
                value: orderTotal.toFixed(2)
              }
            }]
          });
        },
        
        onApprove: function(data, actions) {
          return actions.order.capture().then(function(orderData) {
            // Successful capture
            const transaction = orderData.purchase_units[0].payments.captures[0];
            
            // Clear cart
            localStorage.setItem('dropshop-cart', JSON.stringify([]));
            
            // Show success message
            document.getElementById('paypal-button-container').style.display = 'none';
            document.getElementById('payment-success').style.display = 'block';
            
            // Send order to dropshipping supplier (in a real implementation)
            // This would typically be handled by a backend service
            console.log('Transaction completed by ' + orderData.payer.name.given_name);
            console.log('Transaction ID: ' + transaction.id);
          });
        }
      }).render('#paypal-button-container');
    }
  }
  
  // Cart functionality
  const cart = {
    items: JSON.parse(localStorage.getItem('dropshop-cart')) || [],
    
    addItem: function(product) {
      const existingItem = this.items.find(item => item.id === product.id);
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        this.items.push({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          quantity: 1
        });
      }
      
      this.saveCart();
      this.updateCartDisplay();
    },
    
    removeItem: function(productId) {
      this.items = this.items.filter(item => item.id !== productId);
      this.saveCart();
      this.updateCartDisplay();
    },
    
    updateQuantity: function(productId, quantity) {
      const item = this.items.find(item => item.id === productId);
      if (item) {
        item.quantity = parseInt(quantity);
        if (item.quantity < 1) item.quantity = 1;
      }
      this.saveCart();
      this.updateCartDisplay();
    },
    
    saveCart: function() {
      localStorage.setItem('dropshop-cart', JSON.stringify(this.items));
    },
    
    updateCartDisplay: function() {
      const cartCount = document.querySelector('.cart-count');
      const cartItems = document.querySelector('.cart-items');
      const cartTotal = document.querySelector('.cart-total');
      
      if (cartCount) {
        const itemCount = this.items.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = itemCount;
      }
      
      if (cartItems) {
        cartItems.innerHTML = '';
        
        if (this.items.length === 0) {
          cartItems.innerHTML = '<p>Your cart is empty</p>';
          document.querySelector('.checkout-button').style.display = 'none';
        } else {
          this.items.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
              <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
              </div>
              <div class="cart-item-details">
                <h5>${item.name}</h5>
                <p>$${item.price.toFixed(2)}</p>
                <div class="quantity-control">
                  <button class="quantity-decrease" data-id="${item.id}">-</button>
                  <input type="number" value="${item.quantity}" min="1" data-id="${item.id}">
                  <button class="quantity-increase" data-id="${item.id}">+</button>
                </div>
              </div>
              <button class="remove-item" data-id="${item.id}">×</button>
            `;
            cartItems.appendChild(itemElement);
          });
          
          document.querySelector('.checkout-button').style.display = 'block';
          
          // Add event listeners for quantity controls
          document.querySelectorAll('.quantity-decrease').forEach(button => {
            button.addEventListener('click', function() {
              const id = this.getAttribute('data-id');
              const item = cart.items.find(item => item.id === parseInt(id));
              if (item && item.quantity > 1) {
                cart.updateQuantity(parseInt(id), item.quantity - 1);
              }
            });
          });
          
          document.querySelectorAll('.quantity-increase').forEach(button => {
            button.addEventListener('click', function() {
              const id = this.getAttribute('data-id');
              const item = cart.items.find(item => item.id === parseInt(id));
              if (item) {
                cart.updateQuantity(parseInt(id), item.quantity + 1);
              }
            });
          });
          
          document.querySelectorAll('.quantity-control input').forEach(input => {
            input.addEventListener('change', function() {
              const id = this.getAttribute('data-id');
              cart.updateQuantity(parseInt(id), this.value);
            });
          });
          
          document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', function() {
              const id = this.getAttribute('data-id');
              cart.removeItem(parseInt(id));
            });
          });
        }
      }
      
      if (cartTotal) {
        const total = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        cartTotal.textContent = `$${total.toFixed(2)}`;
      }
    }
  };
  
  // Initialize cart display
  cart.updateCartDisplay();
  
  // Add to cart buttons
  document.querySelectorAll('.btn-add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
      const productId = parseInt(this.getAttribute('data-item-id'));
      const productName = this.getAttribute('data-item-name');
      const productPrice = parseFloat(this.getAttribute('data-item-price'));
      const productImage = this.getAttribute('data-item-image');
      
      cart.addItem({
        id: productId,
        name: productName,
        price: productPrice,
        image: productImage
      });
      
      // Show confirmation message
      const confirmationMessage = document.createElement('div');
      confirmationMessage.className = 'alert alert-success';
      confirmationMessage.textContent = 'Product added to cart!';
      confirmationMessage.style.position = 'fixed';
      confirmationMessage.style.top = '20px';
      confirmationMessage.style.right = '20px';
      confirmationMessage.style.zIndex = '1000';
      document.body.appendChild(confirmationMessage);
      
      setTimeout(() => {
        confirmationMessage.remove();
      }, 3000);
    });
  });
  
  // Initialize PayPal button if on checkout page
  if (window.paypal) {
    initPayPalButton();
  }
});
